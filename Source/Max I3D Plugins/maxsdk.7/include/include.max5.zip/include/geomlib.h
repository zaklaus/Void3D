#ifndef _GEOMLIB_H_

#define _GEOMLIB_H_

#define IMPORTING
#include "geom.h"
#undef IMPORTING

#endif // _GEOMLIB_H_
