#ifndef _PARTICLELIB_H_

#define _PARTICLELIB_H_

#define IMPORTING
#include "particle.h"
#undef IMPORTING

#endif // _PARTICLELIB_H_

