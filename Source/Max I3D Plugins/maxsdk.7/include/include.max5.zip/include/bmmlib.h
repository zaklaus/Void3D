#ifndef _BMMLIB_H_
#define _BMMLIB_H_
#define  BMMExport __declspec( dllimport )
#include "bitmap.h"
#endif
