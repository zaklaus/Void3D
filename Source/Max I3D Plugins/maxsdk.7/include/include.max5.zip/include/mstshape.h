/**********************************************************************
 *<
	FILE: mstshape.h

	DESCRIPTION:  Vestigal file; Left in due to multiple makefile dependencies

	CREATED BY: Tom Hudson

	HISTORY: created 12 May 1997

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/

