#ifndef _EXPRLIB_H_

#define _EXPRLIB_H_

#define IMPORTING
#include "expr.h"
#undef IMPORTING

#endif // _EXPRLIB_H_
