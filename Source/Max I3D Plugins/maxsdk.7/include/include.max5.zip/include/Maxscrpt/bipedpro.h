	// Protocols for biped export classes
	
	def_visible_generic(SetNonUniformScale,			"SetNonUniformScale");
