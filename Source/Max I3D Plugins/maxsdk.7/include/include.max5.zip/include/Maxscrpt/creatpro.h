/*	
 *		MAX_create_protocol.h - def_generics for the create MAX objects
 *
 *		see def_abstract_generics.h for more info.
 *
 *	
 *			Copyright � John Wainwright 1996
 *
 */
 
	def_generic(create,	"create");
